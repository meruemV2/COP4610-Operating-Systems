
// Jerry Laplante
// 11/10/ 2021
// COP4610 Assignment 3: Priority Scheduler test

#include "types.h"
#include "user.h"
#include "stat.h"
#include "fcntl.h"

int main(int argc, char *argv[]){
  int pid;
  
  printf(1, "\n\nCreating new processes...\n\n");
  showprocess();

  pid = fork();
  
  if(pid < 0){
    printf(1, "ERROR: forking child process failed...\n");
  }
  else if(pid > 0){
    printf(1, "\n^^^^Parent pid %d initialized to default priority of 50...\n", getpid());
    printf(1, "\nParent creates child process....\n\n");
    showprocess();
    wait();
    sleep(80);
    setpriority(80);
    printf(1, "\nParent %d set to priority 80....\n\n", getpid());
    showprocess();
    showprocess();
    showprocess();
    showprocess();
    showprocess();
    showprocess();
  }
  else{
    int cpid = getpid();
    printf(1, "\n^^^^Child pid %d initialized with priority of 50...\n\n", cpid);
    printf(1,"Child process starts....\n\n");
    showprocess();
    sleep(65);
    setpriority(65);
    printf(1,"\nChild %d set to priority 65.... \n\n", cpid);
    showprocess();
  }

  exit();
}
