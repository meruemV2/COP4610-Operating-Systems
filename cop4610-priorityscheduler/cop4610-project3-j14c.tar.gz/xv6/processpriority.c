
// Jerry Laplante
// sys call to show process pid and its priority number 
#include "types.h"
#include "user.h"
#include "stat.h"
#include "fcntl.h"

int main(int argc, char *argv[]){
  
  showprocess();
  exit();
}
